//id 1: new attack req the user need to corfim/cancel
//id 2; someone try to still your restuarny
//id 3: someone comfirm your send attack
//id 4: someone cancel your send attack
//id 5: someone send a company req
//id 6: company comfirm req