var json_corporate = {
	"type_id":4,
	"levels":[
	{
		"level": 1,
		"price": 1,
		"profit": 300,
		"seconds": 10,
		"minutes": 0,
		"hours": 0,
		"day": 0,
		"img":"www/images/icons/corporate/level1.png"
	},
	{
		"level": 2,
		"price": 1,
		"profit": 300,
		"seconds": 0,
		"minutes": 1,
		"hours": 0,
		"day": 0,
		"img":"www/images/icons/corporate/level1.png"
	},
	{
		"level": 3,
		"price": 1,
		"profit": 300,
		"seconds": 0,
		"minutes": 30,
		"hours": 0,
		"day": 0,
		"img":"www/images/icons/corporate/level1.png"
	},
	{
		"level": 4,
		"price": 1,
		"profit": 300,
		"seconds": 0,
		"minutes": 0,
		"hours": 1,
		"day": 0,
		"img":"www/images/icons/corporate/level1.png"
	},
	{
		"level": 5,
		"price": 1,
		"profit": 300,
		"seconds": 0,
		"minutes": 0,
		"hours": 2,
		"day": 0,
		"img":"www/images/icons/corporate/level1.png"
	},
	{
		"level": 6,
		"price": 1,
		"profit": 300,
		"seconds": 0,
		"minutes": 0,
		"hours": 4,
		"day": 0,
		"img":"www/images/icons/corporate/level1.png"
	},
	{
		"level": 7,
		"price": 1,
		"profit": 300,
		"seconds": 0,
		"minutes": 0,
		"hours": 6,
		"day": 0,
		"img":"www/images/icons/corporate/level1.png"
	}
]}