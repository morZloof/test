var json_accountant = {
    "type_id":5,
    "levels":[
        {
            "level": 1,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 3000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 2,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 4000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 3,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 5000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 4,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 6000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 5,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 7000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 6,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 8000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 7,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 9000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 8,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 10000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 9,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 11000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        },
        {
            "level": 10,
            "price": 100000,
            "profit": 0,
            "seconds": 10,
            "minutes": 0,
            "hours": 0,
            "day": 0,
            "maxMoney": 12000000,
            "mainBuilding": 1,
            "img": "www/images/icons/accountant/level1.png"
        }
    ]}